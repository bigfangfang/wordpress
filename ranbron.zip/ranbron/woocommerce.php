<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package ranbron
 */

get_header(); ?>

<?php do_action( 'tt_before_mainblock' ); ?>

<div class=" mainblock" id="full-width-page-wrapper">

    <div  id="content" class="container">

	   <div class="row">
		   <div id="primary" class="col-md-12 content-area">

	            <main id="main" class="site-main">

                <!-- The WooCommerce loop -->
                <?php woocommerce_content(); ?>

	            </main><!-- #main -->

		    </div><!-- #primary -->
	    </div><!-- .row -->

    </div><!-- Container end -->

</div><!-- Wrapper end -->

<?php get_footer(); ?>
