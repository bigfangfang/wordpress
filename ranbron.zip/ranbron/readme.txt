##########

Thank you very much for buying Templatation.com ( or any one from our partners. ) theme.
Please start with reading the <Themeforest-main-download>/Documentation/

If you have any question, please email me from my themeforest profile page here :
http://themeforest.net/user/Templatation?ref=templatation#contact
(The form will only visible if you are logged into Themeforest, and when themeforest delivers your message to me it also tells me if you purchased any of my item.)
Note: We also partner with other authors and release theme from their account, so please message from related author profile page.

I will get back to you within few hours.

Feel free to visit for other cool products and addons : Templatation.com

#########