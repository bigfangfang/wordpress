<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/*-----------------------------------------------------------------------------------*/
/* Start templatation Functions - Please refrain from editing this section
/*-----------------------------------------------------------------------------------*/

include_once get_template_directory(). '/inc/constants.php';   // Theme constants
include_once get_template_directory(). '/inc/init.php';        // Theme loading starts.
add_filter( 'breadcrumb_trail_inline_style', '__return_false' );

/*-----------------------------------------------------------------------------------*/
/* You can put your own functions below temporarily.
/*-----------------------------------------------------------------------------------*/
/**
 * Please note any content you write here will be overwritten with theme update.
 * Its recommended to use child theme instead if you want to write your own functions.
 */









/*-----------------------------------------------------------------------------------*/
/* /End
/*-----------------------------------------------------------------------------------*/
