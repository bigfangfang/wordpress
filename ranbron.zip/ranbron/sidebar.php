<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package ranbron
 */

if ( ! is_active_sidebar( 'default-sidebar' ) ) {
	return;
}
?>

<div id="secondary" class="col-md-3 widget-area" role="complementary">
	<div class="sidebar-right sidebar">
		<?php dynamic_sidebar( 'default-sidebar' ); ?>
	</div>
</div><!-- #secondary -->
