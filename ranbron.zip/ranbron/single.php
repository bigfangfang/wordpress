<?php
/**
 * The template for displaying all single posts.
 *
 * @package ranbron
 */

get_header(); ?>

<?php ranbron_hero_bg(); ?>

<!--================Blog Details Area =================-->
<div class="blog-with-sidebar single-blog-post-page sec-pad mainblock">
    <div class="container">
        <div class="row">
            <div class="<?php if ( is_active_sidebar( 'default-sidebar' ) ) : ?> col-md-9 <?php else : ?>col-md-12<?php endif; ?>">
                <div class="has-right-sidebar">
	                <main id="main" class="site-main">

	                    <?php while ( have_posts() ) : the_post(); ?>

	                        <?php get_template_part( 'templates/content', 'single' ); ?>

							<!-- Post nav -->
							<div class="clearfix mbottom20"></div>
							<?php if( function_exists('ranbron_tt_prev_post') ) echo ranbron_tt_prev_post(); ?>
							<?php if( function_exists('ranbron_tt_next_post') ) echo ranbron_tt_next_post(); ?>
							<div class="clearfix"></div>


	                        <?php
	                        // If comments are open or we have at least one comment, load up the comment template
	                        if ( comments_open() || get_comments_number() ) :
	                            comments_template();
	                        endif;
	                        ?>

	                    <?php endwhile; // end of the loop. ?>

	                </main><!-- #main -->
                </div>
            </div>
            <?php get_sidebar(); ?>
        </div>
    </div>
</div>
<!--================End Bolg Details Area =================-->

<?php get_footer(); ?>



