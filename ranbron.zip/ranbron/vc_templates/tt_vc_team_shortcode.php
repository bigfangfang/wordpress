<?php


$list_type = '';

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
$img = (is_numeric($image) && !empty($image)) ? wp_get_attachment_url($image) : '';

?>

<div class="single-advisor  text-center">
    <div class="img-box">
        <img src="<?php echo esc_url($img); ?>" alt="<?php echo ranbron_fw_img_alt($image); ?>" />
        <div class="overlay">
            <div class="box">
                <div class="content">
	                <?php if( '' != $link1 ) { ?>
                    <a href="<?php echo esc_url( $link1 ); ?>" class="<?php echo esc_attr( $icon1 ); ?>"></a>
	                <?php } if( '' != $link2 ) { ?>
                    <a href="<?php echo esc_url( $link2 ); ?>" class="<?php echo esc_attr( $icon2 ); ?>"></a>
	                <?php } if( '' != $link3 ) { ?>
                    <a href="<?php echo esc_url( $link3 ); ?>" class="<?php echo esc_attr( $icon3 ); ?>"></a>
	                <?php } if( '' != $link4 ) { ?>
                    <a href="<?php echo esc_url( $link4 ); ?>" class="<?php echo esc_attr( $icon4 ); ?>"></a>
	                <?php } ?>
                </div><!-- /.content -->
            </div><!-- /.box -->
        </div><!-- /.overlay -->
    </div><!-- /.img-box -->
    <h3><?php echo esc_attr( $name ); ?></h3>
    <span><?php echo esc_attr( $post ); ?></span>
</div>