<?php
/**
 * @package ranbron
 */
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

extract($atts);
?>

<?php if( 'light' == $type ) { ?>
<div class="sec-title tt-light">
	<h2><?php echo esc_attr($up_title); ?></h2>
	<p><?php echo wp_kses($content, ranbron_tt_allowed_tags()); ?></p>
	<div class="line"></div><!-- /.line -->
</div>
<?php } else { ?>
<div class="sec-title">
	<div class="tag-line"><?php echo esc_attr($up_title); ?></div><!-- /.tag-line -->
	<h2><?php echo wp_kses($content, ranbron_tt_allowed_tags()); ?></h2>
</div>
<?php } ?>