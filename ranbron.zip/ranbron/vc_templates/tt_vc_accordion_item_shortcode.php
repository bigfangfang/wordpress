<?php
/**
 * @package ranbron
 */
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

extract($atts);

?>

<div class="accrodion <?php if( 'yes' == $active) echo 'active'; ?>">
	<div class="accrodion-title">
		<h4><?php echo esc_attr($title); ?></h4>
	</div>
	<div class="accrodion-content">
		<p><?php echo do_shortcode(wp_kses($content, ranbron_tt_allowed_tags())); ?></p>
	</div>
</div>
