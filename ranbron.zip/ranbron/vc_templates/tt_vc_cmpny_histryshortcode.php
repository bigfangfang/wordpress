<?php
/**
 * @package ranbron
 */
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

extract($atts);

?>

<section class="company-history-area">
    <div class="thm-container">
		<?php print do_shortcode($content); ?>
    </div><!-- /.thm-container -->
</section><!-- /.company-history-area -->