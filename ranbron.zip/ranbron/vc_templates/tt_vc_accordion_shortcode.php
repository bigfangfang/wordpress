<?php
/**
 * @package ranbron
 */
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

extract($atts);

?>

<div class="accrodion-grp" data-grp-name="faq-accrodion">
<?php print do_shortcode($content); ?>
</div>
