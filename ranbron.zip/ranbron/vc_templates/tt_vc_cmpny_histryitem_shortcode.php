<?php
/**
 * @package ranbron
 */
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

extract($atts);

?>

<div class="single-company-history">
    <div class="year-box">
        <div class="inner">
            <?php echo esc_html($year); ?>
        </div><!-- /.inner -->
    </div><!-- /.year-box -->
    <div class="text-box">
        <h3><?php echo esc_html($title); ?></h3>
		<p><?php echo do_shortcode(wp_kses($content, ranbron_tt_allowed_tags())); ?></p>
    </div><!-- /.text-box -->
</div><!-- /.single-company-history -->