<?php
/**
 * @package ranbron
 */
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

extract($atts);

?>
<div class="single-fun-fact">
	<div class="line"></div><!-- /.line -->
	<span class="number counter"><?php echo esc_attr($number); ?></span>
	<p><?php echo esc_attr($label); ?></p>
</div>