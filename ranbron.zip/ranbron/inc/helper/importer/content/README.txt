The main import file is Import.xml.

The Import_0.xml, Import_1.xml etc are parts of Import.xml file created using a python script. The plugin imports  Import_0.xml, Import_1.xml upto 10 by default.