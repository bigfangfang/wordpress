<?php
/**
 * ranbron Custom css
 *
 * @package ranbron
 */

if(!( function_exists('ranbron_inline_custom_css') )) {
	function ranbron_inline_custom_css( $force = false ) {

		global $tt_temptt_opt;
		$output = $body_image = '';
		// Get options
		$settings = array(
						'top_nav_color' => '',
						'main_acnt_clr' => '',
						'secondary_acnt_clr' => '',
						'h_typography' => '',
						'custom_css' => ''
						);
		$settings = ranbron_fw_opt_values( $settings );


		if($force) { // we have been forced to show specific colors.
			$settings['main_acnt_clr'] = $tt_temptt_opt['tt_main_acnt_clr'];
		}


		// Type Check for Array
		if ( is_array($settings) ) {

		if ( ! ( $settings['main_acnt_clr'] == '' )) { // if usr changed!
			$output .= '


.bac{} /*its here for inconsistency fix. */

button, html input[type=button], input[type=reset], input[type=submit], button:hover, html input[type=button]:hover, input[type=reset]:hover, input[type=submit]:hover, .tt_submit, .slider-home-one .content a.thm-button, .about-home-one a.more-btn, .blog-area .single-blog-post a.read-more, .tt_next_post, .tt_prev_post, .blog-with-sidebar .single-blog-post-sidebar a.read-more, .blog-post-pagination ul li:hover a,
.blog-post-pagination ul li.active a, .blog-post-pagination ul li:hover a,
.blog-post-pagination ul li.active a, .blog-post-pagination ul li a, .btn, .tt-button, form button, .faq-request-area form button[type=submit], .project-area .project-carousel-btn li span:hover, .contact-page .contact-form .tt_submit, .cases-3-col-area .gallery-filter ul li.active span, .cases-3-col-area .gallery-filter ul li:hover span, .cases-3-col-area .single-cases-item .img-box, .sidebar .single-sidebar.broucher-widget a + a, .sidebar .single-sidebar.widget_tag_cloud ul li a:hover, .footer .footer-widget .subscribe-widget .social a:hover, .tt-object, .comment-form .form-submit input,  .pagination  .page-numbers, .advisor-area .sec-title.two a, .advisor-area .sec-title.two a, .advisor-area.about-page a.view-more, .widget_search form
{ border-color: '.$settings['main_acnt_clr'].'; }


button:hover, html input[type=button]:hover, input[type=reset]:hover, input[type=submit]:hover, .tt_submit:hover, .header .header-navigation ul.navigation-box > li > a:after, .header.home-page-three .thm-container, .header.home-page-three .header-navigation.stricky-fixed, .top-bar-home-two, .header-top-home-three .header-top-contact .single-header-top-content a.get-a-qoute-btn, .slider-home-one .content a.thm-button, .request-a-qoute.home-page-two, .sec-title .tag-line:after, .about-home-one a.more-btn:hover, .about-section.about-page .sec-title .tag-line:after, .service-home-one, .service-list .sec-title .tag-line:after, .service-list .single-service-list .title, .service-list .single-service-list .hover-content, .single-service-page-area .service-single-content h3.title:after, .single-service-page-area .service-single-content .feature-box .single-feature .img-box .inner, .blog-area .single-blog-post .img-box .date-box , .tt_next_post:hover,
.tt_prev_post:hover, .blog-with-sidebar .single-blog-post-sidebar a.read-more:hover, .blog-post-pagination ul li:hover a,
.blog-post-pagination ul li.active a, .blog-post-pagination ul li:hover a,
.blog-post-pagination ul li.active a, .comments-area .title h3:after, .single-blog-post-page .leave-a-comment .title h3:after, .btn:hover,
.tt-button:hover, form button:hover, .qoute-faq-area .title h3:after, .faq-request-area form button[type=submit]:hover, .single-fun-fact .line, .project-area .single-project .line, .project-area .project-carousel-btn li span:hover, .testimonial-area .single-testimonial, .testimonial-style-one, .mission-history-area, .call-to-action a.thm-btn, .error-404-area a, .comming-soon-area form .button, .contact-page .sec-title .tag-line:after, .contact-page .contact-form .tt_submit:hover, .contact-page .contact-info.inner, .cases-details-area .cases-info-box, .sidebar .single-sidebar .title h3:after , .sidebar .single-sidebar.sidebar-service-list ul li a:hover, .sidebar .single-sidebar.sidebar-service-list ul li.active a, .sidebar .single-sidebar.broucher-widget a + a, .sidebar .single-sidebar.widget_tag_cloud ul li a:hover, .tt-title.type-2:after, .tt-service-img, .tt-sidebar-service-list li.active a, .tt-sidebar-service-list li a:hover, .what-we-do-area .sec-title .line, .what-we-do-area .single-what-we-do .icon-box .inner, .video-box-area, .request-a-call-back .title h3:after, .request-a-call-back .rqa-form input[type="submit"], .request-a-call-back .rqa-form .bootstrap-select .dropdown-menu > li > a:hover, .request-call-back-two, .company-history-area .single-company-history .year-box .inner, .scrollup,  .pagination  .page-numbers.current,  .pagination  a:hover,  .pagination  a:focus,  .project-area .sec-title .line, .advisor-area .sec-title .line, .advisor-area.about-page .sec-title h2:after, .cases-details-area .title h3:after, .footer .footer-widget .footerform input.button, .widget_search form
{ background-color:'.$settings['main_acnt_clr'].'; }


.site-main a, button, html input[type=button], input[type=reset], input[type=submit], .tt_submit, #page-wrapper .side-ribbon .social a:hover, .header .header-navigation ul.navigation-box > li.current-menu-item > a,
.header .header-navigation ul.navigation-box > li.current > a,
.header .header-navigation ul.navigation-box > li:hover > a, .header .header-navigation ul.navigation-box > li > .sub-menu li:hover > a, .header .header-navigation ul.navigation-box > li > ul > li > .sub-menu li:hover > a, .header.home-page-two .header-navigation ul.navigation-box > li.current-menu-item > a, .header.home-page-two .header-navigation ul.navigation-box > li:hover > a, .header.home-page-four .search-icon-box a:hover, .header.home-page-four .header-navigation ul.navigation-box > li.current-menu-item > a,
.header.home-page-four .header-navigation ul.navigation-box > li:hover > a, .header.home-page-four .header-navigation ul.navigation-box > li:hover > a, .header.home-page-four .header-navigation .thm-container .right-side-box .social li a, .header.home-page-five .search-icon-box a:hover, .header.home-page-five .header-navigation ul.navigation-box > li.current-menu-item > a,
.header.home-page-five .header-navigation ul.navigation-box > li:hover > a, .header.home-page-five .header-navigation ul.navigation-box > li:hover > a, .header.home-page-five .header-navigation .thm-container .right-side-box .social li a, .top-bar-home-three .right-social ul li a, .header-top-home-three .header-top-contact .single-header-top-content .icon-box i, .slider-home-one .content a.thm-button:hover, .sec-title h2 span, .sec-title h2 strong, .about-home-one a.more-btn, .about-section.about-page .sec-title h2 span, .about-home-two .about-content h2 strong,
.about-home-two .about-content h2 span, .service-list .sec-title h2 span, .blog-area .single-blog-post h3:hover, .blog-area .single-blog-post a.read-more, .blog-with-sidebar .single-blog-post-sidebar .meta-info-box a.date, .blog-with-sidebar .single-blog-post-sidebar a:hover, .tt_next_post,
.tt_prev_post, .blog-with-sidebar .single-blog-post-sidebar a.read-more, .blog-post-pagination ul li a, .comments-area .single-comment .text-box .meta-info a,  .btn, .tt-button, form button, .tt_prev_post, .tt_next_post, .qoute-faq-area .qoute-content p.highlighted, .faq-request-area form button[type=submit], .single-fun-fact span.number, .single-fun-fact p, .project-area .single-project h3:hover, .call-to-action a.thm-btn:hover, .error-404-area h2, .error-404-area a:hover, .comming-soon-area ul li .box h4, .comming-soon-area ul li .box span, .contact-page .sec-title h2 span, .contact-page .contact-form .tt_submit, .cases-3-col-area .gallery-filter ul li.active span, .cases-3-col-area .gallery-filter ul li:hover span, .sidebar .single-sidebar.contact-info .single-contact-info .icon-box i, .sidebar .single-sidebar.broucher-widget a, .sidebar .single-sidebar ul li a:hover, .sidebar .single-sidebar.widget_temptt_widget_recentpost .single-post .text-box h4:hover, .footer .footer-widget ul li a:hover, .footer .footer-widget .subscribe-widget form button, .footer .footer-widget .footerform input.button, .footer .footer-widget .subscribe-widget .social a:hover, .tt-contact-info p:before, .tt-contact-info p:last-child:before, .tt-broucher a, .comment-form .form-submit input, .pagination  a.active.project-area .sec-title p, .project-area .sec-title p, .blog-area .blog-post-list .single-post-list h3:hover, .blog-area .blog-post-list .single-post-list span, .advisor-area .sec-title.two a, .advisor-area.about-page a.view-more
{ color: '.$settings['main_acnt_clr'].'; }


@media(max-width: 1024px){
    .header .navbar-toggle:hover .icon-bar {background: '.$settings['main_acnt_clr'].';}
    .header.home-page-four .navbar-toggle:hover .icon-bar {background: '.$settings['main_acnt_clr'].';}
    .header.home-page-five .navbar-toggle .icon-bar {background: '.$settings['main_acnt_clr'].';}
}
.service-home-one .single-service-home-one a, .service-list .single-service-list .hover-content a, .mission-history-area ul.list-item li, .testimonial-style-one .single-testimonial .text-box span.position {
  color: #fff;
}

.single-advisor .img-box .overlay, .project-area .single-project .img-box .overlay, .cases-3-col-area .single-cases-item .img-box .overlay
{ background:'.$settings['main_acnt_clr'].'; }

.single-advisor .img-box .overlay:hover, .project-area .single-project .img-box .overlay:hover, .cases-3-col-area .single-cases-item .img-box .overlay:hover
{ opacity: .75; }




						';
		}

		if ( ! ( $settings['secondary_acnt_clr'] == '' )) { // if usr changed!
			$output .= '

						';
		}

		if ( ! ( $settings['h_typography'] == '' )) { // if usr changed!
			$output .= '
.bac{}
.main_title h2, .service_item h4, .discover_item_inner .discover_item h4
{ font-family: "'.$settings['h_typography']['font-family'].'"; }

						';
		}


			if ( $settings['top_nav_color'] != '' ) {
				$output .= 'header.sticky { background: ' . $settings['top_nav_color'] . ' }' . "\n";
			}
		} // End If Statement

		
		// Output styles
		if ( isset( $output ) && $output != '' ) {
			$output = strip_tags( $output );
			// Remove space after colons
			$output = str_replace(': ', ':', $output);
			// Remove whitespace
			$output = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '   ', '    '), '', $output);

			$output = "\n" . "<!-- Theme Custom Styling -->\n<style type=\"text/css\">\n" . $output . "</style>\n";
			wp_add_inline_style( 'ranbron-style', $output );
		}

	}

	add_action( 'wp_enqueue_scripts', 'ranbron_inline_custom_css', 100 );
}
