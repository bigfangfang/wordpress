<?php
/*
 * Templatation.com
 *
 * Banner with label slider for VC
 *
 */

function tt_vc_countdown_fn_vc() {
    vc_map(
        array(
            'name'                    => esc_html__( 'Ranbron Countdown' , 'ranbron' ),
            'base'                    => 'tt_vc_countdown_shortcode',
			"icon"     => 'tt-vc-block',
            "category" => esc_html__('Ranbron', 'ranbron'),
			"params" => array(
                array(
                    'type'        => 'textfield',
                    'heading'     => esc_html__( 'Number', 'ranbron' ),
                    'param_name'  => 'number',
                    'admin_label' => true,
                    'value'       => '',
                ),
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => esc_html__("Label",'ranbron'),
					"param_name" => "label",
                    'admin_label' => true,
					"value" => "",
			    ),
			),
        )
    );
}
add_action( 'vc_before_init', 'tt_vc_countdown_fn_vc' );
// A must for container functionality, replace Wbc_Item with your base name from mapping for parent container
if(class_exists('WPBakeryShortCode')){
    class WPBakeryShortCode_tt_vc_countdown_shortcode extends WPBakeryShortCode {

    }
}
