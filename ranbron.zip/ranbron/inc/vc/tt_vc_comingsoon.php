<?php
/*
 * Templatation.com
 *
 *
 */

function tt_vc_comingsoon_fn_vc() {
    vc_map(
        array(
            'name'                    => esc_html__( 'Ranbron Coming Soon Content' , 'ranbron' ),
            'base'                    => 'tt_vc_comingsoon_shortcode',
			"icon"     => 'tt-vc-block',
            "category" => esc_html__('Ranbron', 'ranbron'),
			"params" => array(

		                array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Title', 'ranbron' ),
							'param_name'	=> 'title',
							'value'			=> 'Coming',
							'admin_label'	=> true,
						),
		                array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Title 2', 'ranbron' ),
							'param_name'	=> 'title2',
							'value'			=> 'Soon',
							'description'	=> esc_html__( 'This title comes in highlight color.', 'ranbron' ),
							'admin_label'	=> true,
						),
		                array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Date', 'ranbron' ),
							'param_name'	=> 'date',
							'value'			=> '2019/07/12',
							'description'	=> esc_html__( 'Date of launch. in YYYY/DD/MM format.', 'ranbron' ),
							'admin_label'	=> true,
						),
						array(
							'type'			=> 'textarea',
							'heading'		=> esc_html__( 'Description', 'ranbron' ),
							'param_name'	=> 'desc',
						),
	                )
        )
    );
}
add_action( 'vc_before_init', 'tt_vc_comingsoon_fn_vc' );
// A must for container functionality, replace Wbc_Item with your base name from mapping for parent container
if(class_exists('WPBakeryShortCode')){
    class WPBakeryShortCode_tt_vc_comingsoon_shortcode extends WPBakeryShortCode {

    }
}
