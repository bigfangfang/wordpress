<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }
/*
 * Templatation.com
 *
 * VC integration
 *
 */

// Set VC as theme.
if( function_exists('vc_set_as_theme') ){
	function ranbron_fw_vcAsTheme() {
		vc_set_as_theme(true);
	}
	add_action( 'vc_before_init', 'ranbron_fw_vcAsTheme' );
}
vc_set_default_editor_post_types( array(
									    'page',
									    'tt_project',
										'tt_portfolio'
									) );



// Initialize VC modules.
ranbron_load_proper_file('/inc/vc/tt_vc_title.php');
ranbron_load_proper_file('/inc/vc/tt_vc_button.php');
ranbron_load_proper_file('/inc/vc/tt_vc_accordion.php');
ranbron_load_proper_file('/inc/vc/tt_vc_cmpy_history.php');
ranbron_load_proper_file('/inc/vc/tt_vc_countdown.php');
ranbron_load_proper_file('/inc/vc/tt_vc_practise.php');
ranbron_load_proper_file('/inc/vc/tt_vc_team.php');
ranbron_load_proper_file('/inc/vc/tt_vc_comingsoon.php');
ranbron_load_proper_file('/inc/vc/tt_vc_add_content.php');
ranbron_load_proper_file('/inc/vc/tt_vc_logo_carousel.php');
ranbron_load_proper_file('/inc/vc/tt_vc_service.php');
