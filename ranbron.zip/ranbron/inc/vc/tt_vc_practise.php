<?php
/*
 * Templatation.com
 *
 * Banner with label slider for VC
 *
 */

function tt_vc_practise_fn_vc() {
    vc_map(
        array(
            'name'                    => esc_html__( 'Ranbron Practise' , 'ranbron' ),
            'base'                    => 'tt_vc_practise_shortcode',
			"icon"     => 'tt-vc-block',
            'description'             => esc_html__( 'Practise area block.', 'ranbron' ),
            "category" => esc_html__('Ranbron', 'ranbron'),
			"params" => array(
                array(
                    'type'        => 'textfield',
                    'heading'     => esc_html__( 'Title', 'ranbron' ),
                    'param_name'  => 'title',
                    'admin_label' => true,
                    'value'       => '',
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__( 'Image', 'ranbron' ),
                    'param_name' => 'image',
                    'value' => '',
                    'description' => esc_html__( 'Select image from media library. Size 250x250 preferred.', 'ranbron' ),
                ),
				array(
					"type" => "vc_link",
					"class" => "",
					"heading" => esc_html__("Link",'ranbron'),
					"param_name" => "btn_link",
					"value" => "",
			    ),
			),
        )
    );
}
add_action( 'vc_before_init', 'tt_vc_practise_fn_vc' );
// A must for container functionality, replace Wbc_Item with your base name from mapping for parent container
if(class_exists('WPBakeryShortCode')){
    class WPBakeryShortCode_tt_vc_practise_shortcode extends WPBakeryShortCode {

    }
}
