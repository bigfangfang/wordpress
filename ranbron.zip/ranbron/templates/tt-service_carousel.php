<?php
if ( ! defined( 'ABSPATH' ) ) exit;

 /*
  *  template file
  * @templatation.com
  */
?>


<div class="service-home-one-carousel owl-carousel owl-theme">
	<?php
		// Posts are found
		if ( $posts->have_posts() ) {
			while ( $posts->have_posts() ) :
				$posts->the_post();
				global $post;
				?>
				<?php
					$single_data2 = $single_testi_pos = '';
					$single_data2 = get_post_meta( $post->ID, '_tt_meta_page_opt', true );
					if( is_array($single_data2) ) {
						if ( isset( $single_data2['_sc_icon'] ) ) {
							$sc_icon = $single_data2['_sc_icon'];
						}
					}
				?>

			<div class="item">
				<div class="single-service-home-one">
		            <i class="<?php echo esc_attr($sc_icon); ?>"></i>
					<?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
					<?php the_excerpt(); ?>
					<a href="<?php the_permalink(); ?>"><?php esc_html_e('Read more', 'ranbron'); ?></a>
				</div>
			</div>
			<?php
			endwhile;
		}
		// Posts not found
		else {
			echo '<h4>' . esc_html__( 'Posts not found', 'ranbron' ) . '</h4>';
		}
	?>

</div><!-- /.row -->
