<?php
/**
 * @package ranbron
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('blog-sidebar-wrapper'); ?>>
	<div class="single-blog-post-sidebar clearfix">

		<?php
		the_content();
		?>
	</div><!-- /.single-blog-post-sidebar -->

</article><!-- #post-## -->
