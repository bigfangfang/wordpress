<?php
/**
 * @package ranbron
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('blog-sidebar-wrapper'); ?>>
	<div class="single-blog-post-sidebar clearfix">
    <?php if ( has_post_thumbnail() ) : ?>
        <div class="img-box">
        <?php the_post_thumbnail(array('840', '360')); ?>
	    </div>
    <?php endif; ?>
		<div class="clearfix rnb-content">
			<?php get_template_part( 'templates/entry-meta' ); ?>
	        <?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
			<?php
			the_content();
			?>
		</div>
	</div><!-- /.single-blog-post-sidebar -->

		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links clearfix">' . esc_html__( 'Pages:', 'ranbron' ),
				'after'  => '</div>',
			) );
		?>

	<footer class="entry-footer clearfix">

		<?php ranbron_entry_footer(); ?>

	</footer><!-- .entry-footer -->

	<!-- Author box -->
    <?php if ( ( '' !== get_the_author_meta( 'description' )) && ranbron_fw_get_option( 'post_author', 1 ) ) {
        get_template_part( 'templates/tt-post-author' );
    }
    ?>

</article><!-- #post-## -->
