<header class="header home-page-two">

	<?php if( function_exists('ranbron_topnav_content')) echo ranbron_topnav_content($class='top-bar-home-two'); ?>

    <nav class="navbar navbar-default header-navigation stricky">
        <div class="thm-container clearfix">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".main-navigation" aria-expanded="false">
                    <span class="sr-only"><?php esc_html_e( 'Toggle navigation', 'ranbron' ); ?></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- Logo -->
                <?php if(ranbron_fw_get_option('use_logo', '1')) {
					echo ranbron_fw_logo($type='2');
                } else { ?>
                <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
				<?php } ?>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse main-navigation" id="main-nav-bar">

            <!-- The WordPress Menu goes here -->
            <?php wp_nav_menu(
                    array(
                        'depth'             => 3,
                        'theme_location'    => 'primary-menu',
                        'container_class'   => 'primary-menu-container',
                        'menu_class'        => 'nav navbar-nav navigation-box',
                        'fallback_cb'       => '',
                        'menu_id'           => 'main-menu',
						'walker'          => new Ranbron_WP_Bootstrap_Navwalker(),
                    )
            ); ?>

            </div><!-- /.navbar-collapse -->
	        <?php if ( ranbron_fw_get_option('enable_hdr_search', '1') ) { ?>
            <div class="right-side-box">
                <a href="#vb-search" class="popup-with-zoom-anim search-toggle" ><i class="icon icon-Search"></i></a>
            </div><!-- /.right-side-box -->
	        <?php } ?>
        </div><!-- /.container -->
    </nav>
</header><!-- /.header -->