<?php
/*
 * $temptt_t_vars is an array of custom parameters set for given post shortcode.
 */


?>
<section class="project-area">
    <div class="thm-container">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="sec-title-two">
                    <h3><?php echo esc_html($temptt_t_vars['temptt_var1']); ?></h3>
                    <p><?php echo esc_html($temptt_t_vars['temptt_var2']); ?></p>
                    <ul class="project-carousel-btn list-inline">
                        <li><span class="left-nav"><i class="fa fa-angle-left"></i></span></li>
                        <li><span class="right-nav"><i class="fa fa-angle-right"></i></span></li>
                    </ul><!-- /.project-carousel-btn -->
                </div><!-- /.sec-title-two -->
            </div><!-- /.col-md-3 -->
            <div class="col-md-9 col-sm-6 col-xs-12">
                <div class="project-carousel-home-two owl-carousel owl-theme">
					<?php
						// Posts are found
						if ( $posts->have_posts() ) {
							while ( $posts->have_posts() ) :
								$posts->the_post();
								global $post;
								?>
				                <div class="item">

				                    <div class="single-project">
										<div class="img-box">
											<?php the_post_thumbnail(array('255','240')); ?>
											<div class="overlay">
												<div class="box">
													<div class="content">
														<a href="<?php the_permalink(); ?>"><?php esc_html_e('View Details', 'ranbron'); ?></a>
													</div>
												</div>
											</div>
										</div>
				                        <?php the_title( sprintf( '<a href="%s" rel="bookmark"><h3 class="page-title">', esc_url( get_permalink() ) ), '</h3></a>' ); ?>
				                        <div class="line"></div>
				                    </div>
				                </div>
							<?php
							endwhile;
						}
						// Posts not found
						else {
							echo '<h4>' . esc_html__( 'Posts not found', 'ranbron' ) . '</h4>';
						}
					?>

                </div><!-- /.project-carousel-home-two -->
            </div><!-- /.col-md-9 -->
        </div><!-- /.row -->
    </div><!-- /.thm-container -->
</section><!-- /.project-area -->