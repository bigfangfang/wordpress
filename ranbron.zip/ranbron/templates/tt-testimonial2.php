<?php
/*
 * Template file for testimonial shortcode.
 * $temptt_t_vars is an array of custom parameters set for given post shortcode.
 */

$single_testi_pos = '';
?>

<section class="testimonial-style-one">
    <div class="thm-container">
        <div class="testimonial-carousel-one owl-carousel owl-theme">
	<?php
		// Posts are found
		if ( $posts->have_posts() ) {
			while ( $posts->have_posts() ) :
				$posts->the_post();
				global $post;
				?>
				<?php
					$single_data2 = $single_testi_pos = '';
					$single_data2 = get_post_meta( $post->ID, '_tt_meta_page_opt', true );
					if( is_array($single_data2) ) {
						if ( isset( $single_data2['_single_testi_pos'] ) ) {
							$single_testi_pos = $single_data2['_single_testi_pos'];
						}
					}
				?>

            <div class="item">
                <div class="single-testimonial">
                    <div class="inner-content">
                        <div class="img-box">
                            <div class="inner">
                                <?php echo get_the_post_thumbnail( $post->ID, array('80', '80') ); ?>
                                <span class="qoute-mark">“</span>
                            </div><!-- /.inner -->
                        </div><!-- /.img-box -->
                        <div class="text-box">
                            <?php the_content(); ?>
                            <span class="name">- <?php the_title(); ?></span>
                            <span class="position"><?php echo esc_html($single_testi_pos); ?></span>
                        </div><!-- /.text-box -->
                    </div><!-- /.inner-content -->
                </div><!-- /.single-testimonial -->
            </div><!-- /.item -->
			<?php
			endwhile;
		}
		// Posts not found
		else {
			echo '<h4>' . esc_html__( 'Posts not found', 'ranbron' ) . '</h4>';
		}
	?>
        </div><!-- /.testimonial-carousel-one owl-carousel owl-theme -->

    </div><!-- /.thm-container -->
</section><!-- /.testimonial-style-one -->