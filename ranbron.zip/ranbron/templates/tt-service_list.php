<?php
if ( ! defined( 'ABSPATH' ) ) exit;

 /*
  *  template file
  * @templatation.com
  */
?>

<div class="row">

<?php
	// Posts are found
	if ( $posts->have_posts() ) {
		while ( $posts->have_posts() ) :
			$posts->the_post();
			global $post;
			?>
			<?php
				$single_data2 = $single_testi_pos = '';
				$single_data2 = get_post_meta( $post->ID, '_tt_meta_page_opt', true );
				if( is_array($single_data2) ) {
					if ( isset( $single_data2['_sc_icon'] ) ) {
						$sc_icon = $single_data2['_sc_icon'];
					}
				}
			?>

		<div class="col-md-4 col-sm-6 col-xs-12">
			<div class="single-service-list">
				    <?php if ( has_post_thumbnail() ) : ?>
					      <?php the_post_thumbnail(array('370', '230')); ?>
				    <?php endif; ?>
				<div class="title">
					<?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
				</div><!-- /.title -->
				<div class="hover-content">
					<div class="box">
						<div class="content">
							<?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
							<div class="line"></div><!-- /.line -->
							<p><?php the_excerpt(); ?></p>
							<a href="<?php the_permalink(); ?>"><?php esc_html_e('Read more', 'ranbron'); ?></a>
						</div><!-- /.content -->
					</div><!-- /.box -->
				</div><!-- /.hover-content -->
			</div><!-- /.single-service-list -->
		</div>

		<?php
		endwhile;
	}
	// Posts not found
	else {
		echo '<h4>' . esc_html__( 'Posts not found', 'ranbron' ) . '</h4>';
	}
?>
</div>

