<?php
/*
 * Template file for posts shortcode.
 * $temptt_t_vars is an array of custom parameters set for given post shortcode.
 */

empty($temptt_t_vars['temptt_var1']) || $temptt_t_vars['temptt_var1'] == 'default' ? $bt_cols='4' : $bt_cols = $temptt_t_vars['temptt_var1'];
?>
<div class="tt-posts tt-posts-default-loop blog-area ">
<div class="row blog-post-list2">
	<?php
		// Posts are found
		if ( $posts->have_posts() ) {
			while ( $posts->have_posts() ) :
				$posts->the_post();
				global $post;
				?>
					<div class="single-post-list">
						<?php the_title( sprintf( '<a href="%s" rel="bookmark"><h3 class="page-title">', esc_url( get_permalink() ) ), '</h4></a>' ); ?>
						<span><?php the_time( get_option( 'date_format' ) ); ?></span>
					</div><!-- /.single-post-list -->

				<?php
			endwhile;
		}
		// Posts not found
		else {
			echo '<h4>' . esc_html__( 'Posts not found', 'ranbron' ) . '</h4>';
		}
	?>
</div>
</div>

