<div class="entry-meta meta-info-box clearfix">
	<a href="<?php the_permalink(); ?>" class="date pull-left"><?php echo get_the_date(); ?></a>
	<p class="meta-info pull-right">
        <?php echo sprintf(
esc_html_x( 'By: %s', 'post author', 'ranbron' ),
'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
);?>
    <?php
	if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) { ?>
	<span class="sep">/</span>
	<?php comments_popup_link( esc_html__( '0 comment', 'ranbron' ), esc_html__( '1 Comment', 'ranbron' ), esc_html__( '% Comments', 'ranbron' ) ); ?>
	<?php } ?>
	</p><!-- /.meta-info -->
</div><!-- /.meta-info -->



