<?php
/**
 * @package ranbron
 */
?>
<div <?php post_class('blog-sidebar-wrapper'); ?> id="post-<?php the_ID(); ?>">
	<div class="single-blog-post-sidebar clearfix">
    <?php if ( has_post_thumbnail() ) : ?>
        <div class="img-box">
        <a class="ht-imagehover" href="<?php the_permalink(); ?>"><?php the_post_thumbnail(array('840', '360')); ?></a>
	    </div>
    <?php endif; ?>
		<?php get_template_part( 'templates/entry-meta' ); ?>
        <?php the_title( sprintf( '<h3 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>
		<?php
		the_excerpt();
		?>
		<a href="<?php the_permalink(); ?>" class="read-more"><?php esc_html_e('Read more', 'ranbron'); ?></a>
	</div><!-- /.single-blog-post-sidebar -->
</div><!-- /.blog-sidebar-wrapper -->
<!-- #post-## -->
<div class="pbottom80"></div>
