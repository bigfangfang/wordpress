<?php
/*
 * Template file for testimonial shortcode.
 * $temptt_t_vars is an array of custom parameters set for given post shortcode.
 */

$single_testi_pos = '';
?>

<div class=" col-md-8 col-sm-12 col-xs-12 pull-right p0">
	<div class="owl-carousel owl-theme testimonial-carousel">
	<?php
		// Posts are found
		if ( $posts->have_posts() ) {
			while ( $posts->have_posts() ) :
				$posts->the_post();
				global $post;
				?>
				<?php
					$single_data2 = $single_testi_pos = '';
					$single_data2 = get_post_meta( $post->ID, '_tt_meta_page_opt', true );
					if( is_array($single_data2) ) {
						if ( isset( $single_data2['_single_testi_pos'] ) ) {
							$single_testi_pos = $single_data2['_single_testi_pos'];
						}
					}
				?>

		<div class="item">
			<div class="single-testimonial">
				<div class="inner-content">
	                <?php if ( has_post_thumbnail() ) : ?>
					<div class="img-box">
						<div class="inner">
							<?php echo get_the_post_thumbnail( $post->ID, array('80', '80') ); ?>
							<span class="qoute-mark">"</span>
						</div><!-- /.inner -->
					</div><!-- /.img-box -->
					<?php endif; ?>
					<div class="text-box">
						<?php the_content(); ?>
						<span class="name">- <?php the_title(); ?></span>
					</div><!-- /.text-box -->
				</div><!-- /.inner-content -->
			</div><!-- /.single-testimonial -->
		</div><!-- /.item -->
			<?php
			endwhile;
		}
		// Posts not found
		else {
			echo '<h4>' . esc_html__( 'Posts not found', 'ranbron' ) . '</h4>';
		}
	?>

	</div><!-- /.owl-carousel owl-theme testimonial-carousel -->
</div><!-- /.col-md-6 -->