<?php
/*
 * $temptt_t_vars is an array of custom parameters set for given post shortcode.
 */

wp_enqueue_script( 'isotope', get_template_directory_uri() . '/assets/assets/isotope.js', array('jquery'), null, true );

?>

<section class="cases-3-col-area sec-pad">
	<div class="thm-container">
		<div class="gallery-filter">
<?php
// Posts are found
if ( $posts->have_posts() ) {
	if($temptt_t_vars['temptt_show_filters'] == 'yes' ) {
	                $sub_cat_args = array('hide_empty' => 0, 'orderby' => 'ID');
	                $sub_cat_terms = get_terms('tt_project_cats', $sub_cat_args);
	                if (!empty($sub_cat_terms) && !is_wp_error($sub_cat_terms)) { ?>
			            <ul class="<?php if($temptt_t_vars['temptt_show_filters'] == 'yes' ) echo ' post-filter masonary '; ?> text-center">
				            <?php if($temptt_t_vars['temptt_filter_all'] == 'yes' ) { ?>
			                <li class="filter active" data-filter=".masonary-item"><span><?php esc_html_e('All', 'ranbron');?></a></span>
						    <?php } ?>
				            <?php foreach ($sub_cat_terms as $sub_cat) {
			                print '<li class="filter " data-filter=".' . $sub_cat->slug . '"><span>' . $sub_cat->name . '</a></span>';
						    } ?>
			            </ul>
	                <?php }
	} ?>
		</div>
		<div class="row <?php if($temptt_t_vars['temptt_show_filters'] == 'yes' ) echo ' masonary-layout filter-layout ';?>" data-filter-class="filter">
	<?php
	while ( $posts->have_posts() ) :
		$posts->the_post();
		global $post;
	            $curent_term_array = wp_get_post_terms(get_the_ID(), 'tt_project_cats');
	            $current_term_string = '';
	            foreach ($curent_term_array as $curent_term_item) {
	                $current_term_string .= ' ' . $curent_term_item->slug;

	            }
		?>

			<div class="col-md-4 col-sm-6 masonary-item single-filter-item <?php if($temptt_t_vars['temptt_show_filters'] == 'yes' ) echo esc_attr($current_term_string);?>">
				<div class="single-cases-item">
	                <?php if ( has_post_thumbnail() ) : ?>
					<div class="img-box">
						<?php the_post_thumbnail(array('570','450')); ?>
						<div class="overlay">
							<div class="box">
								<div class="content">
									<a href="<?php the_permalink(); ?>"><?php esc_html_e('View Details', 'ranbron'); ?></a>
								</div>
							</div>
						</div>
					</div>
					<div class="text-box text-center">
						<?php the_title( sprintf( '<a href="%s" rel="bookmark"><h3 class="page-title">', esc_url( get_permalink() ) ), '</h3></a>' ); ?>
						<p><?php echo esc_attr($curent_term_item->slug);?></p>
					</div><!-- /.text-box -->
					<?php endif; ?>
				</div><!-- /.single-cases-item -->
			</div>

	<?php
	endwhile; ?>
	</div>
	<?php
	}
	// Posts not found
	else {
		echo '<h4>' . esc_html__( 'Cases not found', 'ranbron' ) . '</h4>';
	}
	?>

	</div><!-- /.thm-container -->
</section><!-- /.cases-area -->