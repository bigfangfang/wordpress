<?php
/*
 * Templatation.com
 *
 */
?>
<?php while( $posts->have_posts() ): $posts->the_post();?>
<div class="single-post">
    <?php if ( has_post_thumbnail() ) : ?>
        <div class="img-box">
        <?php the_post_thumbnail(array('70', '60')); ?>
	    </div>
    <?php endif; ?>
	<div class="text-box">
		<?php the_title( sprintf( '<h4 class="news-link"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' ); ?>
		<span class="date"><?php the_time( get_option( 'date_format' ) ); ?></span>
	</div><!-- /.text-box -->
</div>
<?php
endwhile;
?>