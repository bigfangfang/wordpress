<?php
if ( ! defined( 'ABSPATH' ) ) exit;

 /*
  *  template file
  * @templatation.com
  */
?>

<div class="row what-we-do-content-wrapper">

<?php
	// Posts are found
	if ( $posts->have_posts() ) {
		while ( $posts->have_posts() ) :
			$posts->the_post();
			global $post;
			?>
			<?php
				$single_data2 = $single_testi_pos = '';
				$single_data2 = get_post_meta( $post->ID, '_tt_meta_page_opt', true );
				if( is_array($single_data2) ) {
					if ( isset( $single_data2['_sc_icon'] ) ) {
						$sc_icon = $single_data2['_sc_icon'];
					}
				}
			?>
		    <div class="col-md-4 col-sm-6 col-xs-12">
		        <div class="single-what-we-do">
		            <div class="icon-box">
		                <div class="inner">
		                    <i class="<?php echo esc_attr($sc_icon); ?>"></i>
		                </div><!-- /.inner -->
		            </div><!-- /.icon-box -->
		            <div class="text-box">
		                <?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
		                <?php the_excerpt(); ?>
		            </div><!-- /.text-box -->
		        </div><!-- /.single-what-we-do -->
		    </div><!-- /.col-md-4 -->

		<?php
		endwhile;
	}
	// Posts not found
	else {
		echo '<h4>' . esc_html__( 'Posts not found', 'ranbron' ) . '</h4>';
	}
?>
</div>