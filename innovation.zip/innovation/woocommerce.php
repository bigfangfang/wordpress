<?php

//Woocommerce Template
$ruby_woo_options               = array();
$ruby_woo_options['page_title'] = innovation_ruby_util::get_theme_option( 'innovation_ruby_woocommerce_title_shop' );

if ( false === is_product() ) {
	$ruby_woo_options['sidebar_name']     = innovation_ruby_util::get_theme_option( 'innovation_ruby_woocommerce_sidebar_shop' );
	$ruby_woo_options['sidebar_position'] = innovation_ruby_util::get_theme_option( 'innovation_ruby_woocommerce_sidebar_position_shop' );
} else {
	$ruby_woo_options['sidebar_name']     = innovation_ruby_util::get_theme_option( 'innovation_ruby_woocommerce_sidebar_product' );
	$ruby_woo_options['sidebar_position'] = innovation_ruby_util::get_theme_option( 'innovation_ruby_woocommerce_sidebar_position_product' );
	$ruby_woo_options['comment_box']      = innovation_ruby_util::get_theme_option( 'innovation_ruby_woocommerce_comment_box' );
}

if ( empty( $ruby_woo_options['sidebar_name'] ) ) {
	$ruby_woo_options['sidebar_name'] = 'innovation_ruby_sidebar_default';
}


//Remove Shop Page Title
if ( is_shop() ) {
	function shop_title_false() {
		return false;
	}

	if ( empty( $ruby_woo_options['page_title'] ) ) {
		add_filter( 'woocommerce_show_page_title', 'shop_title_false' );
	}
};

//render page
innovation_ruby_template_part::open_page_wrap( 'woocommerce-page-wrap', $ruby_woo_options['sidebar_position'] );
innovation_ruby_template_part::open_page_inner( 'woocommerce-page-inner ruy-page-content-wrap', $ruby_woo_options['sidebar_position'] );
	woocommerce_content();
innovation_ruby_template_part::close_page_inner();

//render sidebar
if ( ! empty( $ruby_woo_options['sidebar_position'] ) && 'none' != $ruby_woo_options['sidebar_position'] ) {
	innovation_ruby_template_part::sidebar( $ruby_woo_options['sidebar_name'] );
}

innovation_ruby_template_part::close_page_wrap();