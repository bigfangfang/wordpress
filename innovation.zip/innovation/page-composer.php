<?php
/*
Template Name: Ruby Page Composer
*/
echo innovation_ruby_composer_render::render_page();
