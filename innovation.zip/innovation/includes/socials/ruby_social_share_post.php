<?php
if ( ! class_exists( 'innovation_ruby_social_share_post' ) ) {
	class innovation_ruby_social_share_post {

		/**-------------------------------------------------------------------------------------------------------------------------
		 * @param string $ruby_class
		 *
		 * @return string
		 * render social share post
		 */
		static function render( $ruby_class = '' ) {

			//create class
			$ruby_social_color = innovation_ruby_util::get_theme_option( 'social_icon_color' );
			$class           = array();
			$class[]         = $ruby_class;
			$class[]         = 'box-share';
			if ( ! empty( $ruby_social_color ) ) {
				$class[] = 'is-color-icon';
			}
			$class = implode( ' ', $class );

			//get data
			$twitter_user       = get_the_author_meta( 'twitter' );
			$enable_google_plus = innovation_ruby_util::get_theme_option( 'share_to_google_plus' );
			$enable_linkedin    = innovation_ruby_util::get_theme_option( 'share_to_linkedin' );
			$enable_pinterest   = innovation_ruby_util::get_theme_option( 'share_to_pinterest' );
			$enable_tumblr      = innovation_ruby_util::get_theme_option( 'share_to_tumblr' );
			$enable_vk          = innovation_ruby_util::get_theme_option( 'share_to_vk' );


			//render
			$str = '';
			$str .= '<div class="' . $class . '">';
			$str .= '<ul class="box-share-inner">';
			//facebook
			$str .= '<li class="box-share-el facebook-button">';
			$str .= '<a href="http://www.facebook.com/sharer.php?u=' . urlencode( get_permalink() ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-facebook color-facebook"></i><span class="social-text">facebook</span></a>';
			$str .= '</li>';
			//twitter
			$str .= '<li class="box-share-el twitter-button">';
			$str .= '<a class="share-to-social" href="https://twitter.com/intent/tweet?text=' . urlencode( strip_tags( get_the_title() ) ) . '&amp;url=' . urlencode( get_permalink() ) . '&amp;via=' . urlencode( $twitter_user ? $twitter_user : get_bloginfo( 'name' ) ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-twitter color-twitter"></i><span class="social-text">Twitter</span></a>';
			$str .= '</li>';
			//google plus
			if ( ! empty( $enable_google_plus ) ) {
				$str .= '<li class="box-share-el google-button">';
				$str .= ' <a href="http://plus.google.com/share?url=' . urlencode( get_permalink() ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-google color-google"></i><span class="social-text">Google +</span></a>';
				$str .= '</li>';
			}
			//pinterest
			if ( ! empty( $enable_pinterest ) ) {
				$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'innovation_ruby_840x500' );
				$str .= '<li class="box-share-el pinterest-button">';
				$str .= '<a href="http://pinterest.com/pin/create/button/?url=' . urlencode( get_permalink() ) . '&amp;media=' . ( ! empty( $image[0] ) ? $image[0] : '' ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-pinterest"></i><span class="social-text">Pinterest</span></a>';
				$str .= '</li>';
			}
			//linkedin
			if ( ! empty ( $enable_linkedin ) ) {
				$str .= '<li class="box-share-el linkedin-button">';
				$str .= '<a href="http://linkedin.com/shareArticle?mini=true&amp;url=' . urlencode( get_permalink() ) . '&amp;title=' . urlencode( strip_tags( get_the_title() ) ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-linkedin"></i><span class="social-text">LinkedIn</span></a>';
				$str .= '</li>';
			}
			//tumblr
			if ( ! empty( $enable_tumblr ) ) {
				$str .= '<li class="box-share-el tumblr-button">';
				$str .= ' <a href="http://www.tumblr.com/share/link?url=' . urlencode( get_permalink() ) . '&amp;name=' . urlencode( strip_tags( get_the_title() ) ) . '&amp;description=' . urlencode( strip_tags( get_the_title() ) ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-tumblr"></i><span class="social-text">Tumblr</span></a>';
				$str .= '</li>';
			}
			//vk
			if ( ! empty( $enable_vk ) ) {
				$str .= '<li class="box-share-el vk-button">';
				$str .= '<a href="http://vkontakte.ru/share.php?url=' . urldecode( get_permalink() ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-vk"></i><span class="social-text">VKontakte</span></a>';
				$str .= '</li>';

			}

			$str .= '</ul>';
			$str .= '</div>';

			return $str;
		}

		/**-------------------------------------------------------------------------------------------------------------------------
		 * @return string
		 * render post share bar social
		 */
		static function render_post_share_bar() {
			//get data
			$twitter_user       = get_the_author_meta( 'twitter' );
			$enable_google_plus = innovation_ruby_util::get_theme_option( 'share_to_google_plus' );
			$enable_linkedin    = innovation_ruby_util::get_theme_option( 'share_to_linkedin' );
			$enable_pinterest   = innovation_ruby_util::get_theme_option( 'share_to_pinterest' );
			$enable_tumblr      = innovation_ruby_util::get_theme_option( 'share_to_tumblr' );
			$enable_vk          = innovation_ruby_util::get_theme_option( 'share_to_vk' );

			//render
			$str = '';
			$str .= '<div class="share-bar-icon">';
			$str .= '<a href="http://www.facebook.com/sharer.php?u=' . urlencode( get_permalink() ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-facebook color-facebook"></i></a>';
			$str .= '<a class="share-to-social" href="https://twitter.com/intent/tweet?text=' . urlencode( strip_tags( get_the_title() ) ) . '&amp;url=' . urlencode( get_permalink() ) . '&amp;via=' . urlencode( $twitter_user ? $twitter_user : get_bloginfo( 'name' ) ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-twitter color-twitter"></i></a>';
			if ( ! empty( $enable_google_plus ) ) {
				$str .= ' <a href="http://plus.google.com/share?url=' . urlencode( get_permalink() ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-google-plus color-google"></i></a>';
			}
			//pinterest
			if ( ! empty( $enable_pinterest ) ) {
				$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'innovation_ruby_840x500' );
				$str .= '<a href="http://pinterest.com/pin/create/button/?url=' . urlencode( get_permalink() ) . '&amp;media=' . ( ! empty( $image[0] ) ? $image[0] : '' ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-pinterest"></i></a>';
			}
			//linkedin
			if ( ! empty ( $enable_linkedin ) ) {
				$str .= '<a href="http://linkedin.com/shareArticle?mini=true&amp;url=' . urlencode( get_permalink() ) . '&amp;title=' . urlencode( strip_tags( get_the_title() ) ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-linkedin"></i></a>';
			}
			//tumblr
			if ( ! empty( $enable_tumblr ) ) {
				$str .= ' <a href="http://www.tumblr.com/share/link?url=' . urlencode( get_permalink() ) . '&amp;name=' . urlencode( strip_tags( get_the_title() ) ) . '&amp;description=' . urlencode( strip_tags( get_the_title() ) ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-tumblr"></i></a>';
			}
			//vk
			if ( ! empty( $enable_vk ) ) {
				$str .= '<a href="http://vkontakte.ru/share.php?url=' . urldecode( get_permalink() ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa fa-vk"></i></a>';
			}
			$str .= '</div>';

			return $str;
		}
	}
}

