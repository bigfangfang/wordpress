<?php

//including ruby page composer
require_once get_template_directory() . '/includes/ruby_composer/ruby_composer_enqueue.php';
require_once get_template_directory() . '/includes/ruby_composer/ruby_composer_setup.php';
require_once get_template_directory() . '/includes/ruby_composer/ruby_composer_config.php';
require_once get_template_directory() . '/includes/ruby_composer/ruby_composer_action.php';
require_once get_template_directory() . '/includes/ruby_composer/ruby_composer_render.php';
require_once get_template_directory() . '/includes/ruby_composer/ruby_composer_block.php';