<?php

////registering page composer css and script
if ( ! function_exists( 'innovation_ruby_register_composer_script' ) ) {
	function innovation_ruby_register_composer_script( $hook ) {
		if ( $hook == 'post.php' || $hook == 'post-new.php' ) {
			wp_enqueue_style( 'innovation_ruby_composer_style', get_template_directory_uri() . '/includes/ruby_composer/css/ruby-composer-style.css', array(), INNOVATION_THEME_VERSION, 'all' );
			wp_enqueue_script( 'innovation_ruby_composer_script', get_template_directory_uri() . '/includes/ruby_composer/js/ruby-composer-script.js', array( 'jquery' ), INNOVATION_THEME_VERSION, true );
		}
	}

	add_action( 'admin_enqueue_scripts', 'innovation_ruby_register_composer_script' );
}

