<div id="main-content-wrap" class="row clearfix">
	<div class="search-no-result ruby-container post-title">
		<?php if ( is_search() ) : ?>
			<h3><?php esc_html_e( 'Opps! No Post for this query', 'innovation' ); ?></h3>
		<?php else : ?>
			<h3><?php esc_html_e( 'Opps! Please add more posts to show this page', 'innovation' ); ?></h3>
		<?php endif; ?>
	</div>
</div>
