<?php
echo innovation_ruby_social_share_post::render('box-share-default');