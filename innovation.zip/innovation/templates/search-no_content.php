<div id="main-content-wrap" class="row clearfix">
	<div class="search-no-result ruby-container post-title">
		<h3><?php esc_html_e( 'Opps! No found post of this search', 'innovation' ); ?></h3>
	</div>
</div>