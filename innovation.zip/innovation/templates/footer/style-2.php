<div class="footer-area-inner footer-style-2">
	<div class="ruby-container row">
		<?php get_template_part('templates/footer/module','footer_logo'); ?>
		<?php get_template_part('templates/footer/module','footer_social'); ?>
	</div>
</div>