<?php
//get blog options
$ruby_cate_id   = innovation_ruby_util::get_page_cate_id();
$ruby_cate_name = get_cat_name( $ruby_cate_id );
?>
<div class="archive-page-header-small ruby-container">
	<h1 class="archive-title post-title">
		<?php echo esc_attr( $ruby_cate_name ); ?>
	</h1>
</div>