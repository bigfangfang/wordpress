<?php
$ruby_aside_header_logo        = innovation_ruby_util::get_theme_option( 'aside_header_site_logo' );
$ruby_aside_header_logo_retina = innovation_ruby_util::get_theme_option( 'aside_header_site_logo_retina' );
?>

<?php if(!empty($ruby_aside_header_logo['url'])) : ?>
	<div class="aside-logo-wrap">
		<div class="aside-logo-inner">
			<?php if ( empty( $ruby_aside_header_logo_retina['url'] ) ) : ?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo" title="<?php bloginfo( 'name' ); ?>">
					<img data-no-retina src="<?php echo esc_url( $ruby_aside_header_logo['url'] ) ?>" height="<?php echo esc_attr($ruby_aside_header_logo['height']); ?>" width="<?php echo esc_attr($ruby_aside_header_logo['width']); ?>"  alt="<?php bloginfo( 'name' ); ?>">
				</a>
			<?php else : ?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo" title="<?php bloginfo( 'name' ); ?>">
					<img data-at2x="<?php echo esc_url($ruby_aside_header_logo_retina['url']); ?>" src="<?php echo esc_url( $ruby_aside_header_logo['url'] ) ?>" height="<?php echo esc_attr($ruby_aside_header_logo['height']); ?>" width="<?php echo esc_attr($ruby_aside_header_logo['width']); ?>"   alt="<?php bloginfo( 'name' ); ?>">
				</a>
			<?php endif; ?>
		</div>
	</div><!--#aside logo wrap -->
<?php endif; ?>
