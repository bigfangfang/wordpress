<div class="nav-search-wrap">

	<a href="#" id="ruby-ajax-form-search" title="<?php esc_attr_e('Search', 'innovation'); ?>" class="nav-search-icon">
		<i class="fa fa-search"></i>
	</a><!--#nav search button-->

	<div id="nav-search-from" class="nav-search-from-wrap" style="display: none">
		<div class="nav-search-form-inner">
			<?php get_template_part( 'templates/searchform' ); ?>
		</div>
	</div>
</div>
