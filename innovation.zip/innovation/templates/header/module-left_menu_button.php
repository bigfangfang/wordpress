<div class="mobile-nav-button left-mobile-nav-button">
	<a href="#" class="ruby-trigger" title="<?php esc_attr_e( 'menu', 'innovation' ) ?>">
		<span class="icon-wrap"></span>
	</a>
</div><!-- #mobile menu button-->