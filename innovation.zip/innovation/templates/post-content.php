<?php
if ( is_single() ) {
	$ruby_class = 'entry';
} else {
	$ruby_class = 'entry post-excerpt';
}
?>

<div class="<?php echo esc_attr( $ruby_class ); ?>">
	<?php the_content(''); ?>
</div><!--#entry-->
