<?php
$ruby_count_views = innovation_ruby_post_views::get_views();
?>

<?php if ( ! empty ( $ruby_count_views ) )  : ?>
	<span class="meta-info-el meta-info-view">
		<?php if ( 1 == $ruby_count_views ) : ?>
			<a href="<?php echo get_permalink() ?>" title="<?php echo strip_tags( get_the_title() ) ?>">
				<span><?php esc_attr_e( '1 view', 'innovation' ); ?></span>
			</a>
		<?php else : ?>
			<a href="<?php echo get_permalink() ?>" title="<?php echo strip_tags( get_the_title() ) ?>">
				<span><?php echo esc_attr( $ruby_count_views ) . ' ' . esc_attr__( 'views', 'innovation' ); ?></span>
			</a>
	<?php endif; ?>
	</span><!--#view meta-->
<?php endif; ?>
