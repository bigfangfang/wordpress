<?php
$ruby_post_categories = get_the_category();
?>
<span class="meta-info-el meta-info-cate">
<?php if ( empty( $ruby_post_categories ) || array( $ruby_post_categories ) ) : ?>
	<?php foreach ( $ruby_post_categories as $ruby_category ) : ?>
		<a href="<?php echo get_category_link( $ruby_category->term_id ) ?>" title="<?php echo esc_attr( strip_tags( $ruby_category->name ) ) ?>">
			<?php echo esc_attr( $ruby_category->cat_name ) ?>
		</a>
	<?php endforeach; ?>
	</span><!--category meta-->
<?php endif; ?>