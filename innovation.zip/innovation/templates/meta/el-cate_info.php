<?php

$ruby_categories       = get_the_category();
$ruby_primary_category = get_post_meta( get_the_ID(), 'innovation_ruby_single_primary_category', true );

//render category
if ( ! empty( $ruby_primary_category ) && ! is_single() ) {

	$ruby_primary_category_name = get_cat_name( $ruby_primary_category );
	$ruby_class                 = 'cate-info-el is-cate-' . strip_tags( $ruby_primary_category );
	$ruby_category_first_text   = mb_substr( $ruby_primary_category_name, 0, 1 );
	$ruby_category_remain_text  = mb_substr( $ruby_primary_category_name, 1 );

	echo '<a class="' . $ruby_class . '" href="' . get_category_link( $ruby_primary_category ) . '" title="' . esc_attr( strip_tags( $ruby_primary_category_name ) ) . '">';
	echo '<span class="cate-text">';
	echo '<span class="cate-text-first">' . esc_attr( $ruby_category_first_text ) . '</span>';
	echo '<span class="cate-text-remain">' . esc_attr( $ruby_category_remain_text ) . '</span>';
	echo '</span>';
	echo '</a>';


} else {

	if ( ! empty( $ruby_categories ) && array( $ruby_categories ) ) {
		foreach ( $ruby_categories as $ruby_category ) {

			$ruby_class                = 'cate-info-el is-cate-' . strip_tags( $ruby_category->term_id );
			$ruby_category_first_text  = mb_substr( $ruby_category->name, 0, 1 );
			$ruby_category_remain_text = mb_substr( $ruby_category->name, 1 );

			echo '<a class="' . $ruby_class . '" href="' . get_category_link( $ruby_category->term_id ) . '" title="' . esc_attr( strip_tags( $ruby_category->name ) ) . '">';
			echo '<span class="cate-text">';
			echo '<span class="cate-text-first">' . esc_attr( $ruby_category_first_text ) . '</span>';
			echo '<span class="cate-text-remain">' . esc_attr( $ruby_category_remain_text ) . '</span>';
			echo '</span>';
			echo '</a>';
		}
	}
}
