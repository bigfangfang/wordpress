<?php
//get header type
$ruby_header_type = innovation_ruby_util::get_theme_option( 'header_style' );

//render
get_template_part( 'templates/header/style', esc_attr( $ruby_header_type ) );
