/*----------------------------------------------------------------
 You can add your script here

 MAKE SURE YOU "BACKUP" THIS FILE, YOUR CUSTOM CAN BE LOSS WHEN YOU UPDATE.

 --------------------------------------------------------------*/
jQuery(document).ready(function ($) {
/* Add your function here */






});

