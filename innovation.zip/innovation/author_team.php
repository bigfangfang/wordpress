<?php
/*
Template Name: Author Team
*/

$ruby_enable_page_title = innovation_ruby_page::check_title();

if ( ! empty( $ruby_enable_page_title ) && 'none' != $ruby_enable_page_title ) {
	get_template_part( 'templates/header/top', 'page_single' );
}

innovation_ruby_template_part::open_page_wrap( 'page-layout-wrap page-author-wrap', 'none' );
innovation_ruby_template_part::open_page_inner( 'page-layout-inner', 'none' );

//get template part
get_template_part( 'templates/section', 'author_team' );

//change to div wrap for single image
add_filter( 'the_content', array( 'innovation_ruby_single', 'add_div_image' ) );

echo '<div class="entry author-team-entry">';
the_content();
echo '</div>';


innovation_ruby_template_part::close_page_inner();
innovation_ruby_template_part::close_page_wrap();
