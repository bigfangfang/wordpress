<?php
/**
 * Innovation created by ThemeRuby
 * Base template file
 */

//get header
get_header();

?>

<body <?php body_class(); innovation_ruby_schema::makeup( 'body' ); ?>>

<?php get_template_part( 'templates/header/block', 'aside' ); ?>
<div class="main-site-outer">
	<?php get_template_part( 'templates/section', 'header' ); ?>
	<div class="main-site-wrap">
		<div class="side-area-mask"></div>
		<div class="site-wrap-outer">
			<div id="ruby-site-wrap" class="clearfix">
				<?php include innovation_ruby_template_path(); ?>
			</div>
		</div>
<?php get_footer(); ?>
