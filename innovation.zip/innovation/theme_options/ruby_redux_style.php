<?php
//register custom theme options style
if ( ! function_exists( 'innovation_ruby_register_theme_options_style' ) ) {
	function innovation_ruby_register_theme_options_style() {
		wp_register_style( 'innovation-ruby-theme-options-style', get_template_directory_uri() . '/theme_options/css/ruby-theme-options.css', array( 'redux-admin-css' ), INNOVATION_THEME_VERSION, 'all' );

		wp_enqueue_style( 'innovation-ruby-theme-options-style' );
	}

	//Check & do action
	if ( is_admin() ) {
		add_action( 'redux/page/innovation_ruby_theme_options/enqueue', 'innovation_ruby_register_theme_options_style' );
	}
};

